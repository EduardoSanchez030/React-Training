import React from 'react';
import './App.css';
//import Person from './Person/Person.js';
import Blog from './containers/Blog/Blog';

class App extends React.Component{
  state = {
    persons: [
      {name:'Martin', age: '32'},
      {name:'Alejandra', age: '31'},
      {name:'Emilio', age: '4'}
    ],
    otherState : 'some other value',
    showPersons: false
  }

  switchNamehandler = (newName) => {
    //console.log('was clicked');
    // Don't do this:  this.state.persons[0].name = 'MARTIN';
    this.setState({
      persons: [
        {name: newName, age: '33'},
        {name:'Alejandra', age: '32'},
        {name:'Emilio', age: '5'}
      ],
      otherState : 'some other value',
      showPersons: false
    });
  }

  nameEventHanlder = (event) => {
    this.setState({
      persons: [
        {name: 'Mart!', age: '33'},
        {name: event.target.value, age: '32'},
        {name:'Emilio', age: '5'}
      ]
    });
  }

  togglePersonHanlder = () => {
    console.log(this.state.showPersons)
    const doesShow = this.state.showPersons;
    this.setState({showPersons: !doesShow})
  }
 
  render(){

    return (
      <div className="App">
        <Blog />
      </div>
    );
    /*const style = {
       backGroundColor: 'white',
       font: 'inherit',
       border: '1px solid blue',
       padding: '8px',
       cursor: 'pointer'
    };

    let persons = null;

    if ( this.state.showPersons ){
      persons = (
                 <div>
                   {this.state.persons.map( person => {
                      return(<Person 
                      name={person.name} 
                      age={person.age}/>)
                   })}
                  { /*<Person 
                    name={this.state.persons[0].name} 
                    age={this.state.persons[0].age}/>
                  <Person
                    name={this.state.persons[1].name} 
                    age={this.state.persons[1].age}
                    click={this.switchNamehandler.bind(this, 'Eduardo')}
                    changed={this.nameEventHanlder}>My Hobbies: Racing</Person>
                  <Person
                    name={this.state.persons[2].name} 
                  age={this.state.persons[2].age} /> }
                </div>
      ); 
    } 

    return (
      <div className="App">
          <h1>Martin's Test</h1>
          <p>This is really working</p>
           {/* not recommended, not so efficient }
           {/* onClick={ () => this.switchNamehandler('Lalo')}>Switch Name</button> }
          <button 
            style={style}            
            onClick={ this.togglePersonHanlder }>Switch Name</button>
            {persons}
            { /*this.state.showPersons === true ?
                <div>
                  <Person 
                    name={this.state.persons[0].name} 
                    age={this.state.persons[0].age}/>
                  <Person
                    name={this.state.persons[1].name} 
                    age={this.state.persons[1].age}
                    click={this.switchNamehandler.bind(this, 'Eduardo')}
                    changed={this.nameEventHanlder}>My Hobbies: Racing</Person>
                  <Person
                    name={this.state.persons[2].name} 
                    age={this.state.persons[2].age} />
                </div> : null
                
            }    
      </div>
    );*/
  } 
}

export default App;


/* React Hooks approach
const App = props => {
  const [ personsState, setPersonsState] = useState({
      persons: [
        {name:'Martin', age: '32'},
        {name:'Alejandra', age: '31'},
        {name:'Emilio', age: '4'}
      ]
    });

    const [ otherState, setOtherState] = useState('some other value');
    
    console.log(personsState, otherState);

    const switchNamehandler = () => {
      // hooks replaes the state, state merges the states
      //console.log('was clicked');
      // Don't do this:  this.state.persons[0].name = 'MARTIN';
      setPersonsState({
        persons: [
          {name:'MARTIN', age: '33'},
          {name:'Alejandra', age: '32'},
          {name:'Emilio', age: '5'}
        ]
      });
    }

  return (
    <div className="App">
        <h1>Martin's Test</h1>
        <p>This is really working</p>
        <button onClick={switchNamehandler}>Switch Name</button>
        <Person name={personsState.persons[0].name} age={personsState.persons[0].age}/>
        <Person name={personsState.persons[1].name} age={personsState.persons[1].age}/>
        <Person name={personsState.persons[2].name} age={personsState.persons[2].age}/>
    </div>
  );
}

export default App; */