import * as actionTypes from '../actions';

const initialState = {
    counter: 0
}

// Reducer
const reducer = (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.INCREMENT:
            /// DOn't do this
            const newState = Object.assign({}, state);
            newState.counter =  newState.counter + 1;
            return newState;
        case actionTypes.DECREMENT:
            return {
                ...state,       
                counter: state.counter -1
            };
        case actionTypes.ADD:
            return {
                ...state,       
                counter: state.counter + action.val
            };
        case actionTypes.SUBTRACT:
            return {
                ...state,       
                counter: state.counter - action.val
               };
        default : return state;
    }
 }

 export default reducer;