import React from 'react';

const labelStyle = {
    backGroundColor: 'white',
    textAlign: 'left',
    paddingTop: '10px'
 };

 const containerStyle = {
     width: '30%',
     margin: 'auto',
     paddingTop: '10px',
     paddingBottom: '20px',
     font: 'inherit'
 }

 const textInputStyle = {
    width: '80%',
    textAlign: 'left'
 }

 const numberInputStyle = {
    width: '30%',
    textAlign: 'left'
 }

const AddOrUpdateUser = (props) => (
            <div>
				<div style={containerStyle}>
					<h1>Create User</h1>
					<p style={labelStyle}>Name:</p>
                    <input type="text" 
                           value= {props.name}
                           style={textInputStyle}></input>
					<p style={labelStyle}>Age:</p>
					     <input type="number" value= {props.age} min="1" max="100" style={numberInputStyle}></input>
					<p style={labelStyle}>Role:</p>
					     <input type="text" value= {props.role} style={textInputStyle}></input>
					<p style={labelStyle}>Image Url:</p>
					      <input type="url" value= {props.img} style={textInputStyle}></input>
				</div>
				<div>
					<button onClick={props.redirect}>Save</button>
				</div>
			</div>
);

export default AddOrUpdateUser;