import React from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux"
import { createUser, updateUser } from "../../actions/actionCreators";



class Create extends React.Component {
	static propTypes = {
		history: PropTypes.object,
		match: PropTypes.object,
		editMode: PropTypes.bool,
		user: PropTypes.object
	}
	
	/// Old Way with state
	/* state= {
		id: "",
		name: "",
		age: 1,
		role: "",
		img: ""
	} */

	createUser = (e) => {
		debugger;
		e.preventDefault();
		this.props.createUser(e);
		this.props.history.push("/users");
	}

	// Deprecated
	postDataHandler = () => {
		const post= {
			name: this.state.name,
			age: this.state.age,
			img: this.state.img,
			role: this.state.role,
			id: Math.floor(Math.random() * 150)
		};
		this.props.createUser(post);
		this.props.history.push("/users");
	  }

	  handleSubmit = e => {
        e.preventDefault();
		const {editMode, user} = this.props;
		const id = user.id;
        const name = this.nameRef.value;
		const age = this.ageRef.value;
		const role = this.roleRef.value;
		const img = this.imgRef.value;
        if (editMode){
            const data = {
                name,
				age,
				role,
				img, 
				id
            }
			this.props.updateUser(data);
			this.props.udated();
        }
        else {
            const data = {
                id: Math.floor(Math.random() * 150),
                name,
				age,
				role,
			    img,
                editing: false
			}
			this.props.createUser(data);
		    this.props.history.push("/users");
        }
	}

	redirect = (e) => {
		e.preventDefault();
		this.props.history.push("/users");
	}

	/* render() {
		return (
			<AddOrUpdateUser id={Math.random() * 100}
			                 name="Martin"
			                 redirect={() => this.createUser()}></AddOrUpdateUser>
		);
	} */

	render() {
		const labelStyle = {
			backGroundColor: 'white',
			textAlign: 'left',
			paddingTop: '10px'
		 };
		
		 const containerStyle = {
			 width: '30%',
			 margin: 'auto',
			 paddingTop: '10px',
			 paddingBottom: '20px',
			 font: 'inherit'
		 }
		
		 const textInputStyle = {
			width: '80%',
			textAlign: 'left'
		 }
		
		 const numberInputStyle = {
			width: '30%',
			textAlign: 'left'
		 }
		
		 // old way with state
		 //value={this.state.age}
		 //onChange={(event) => this.setState({age: event.target.value})}

		 const {editMode, user} = this.props;
		 const pageTitle = editMode ? 'Edit User' : 'Create User';
		 const buttonTitle = editMode ? 'Update' : 'Post';
		return (
			<div>
			<div style={containerStyle}>
		    <h1>{pageTitle}</h1>
				<p style={labelStyle}>Name:</p>
				<input type="text" 
				 style={textInputStyle} 
				 defaultValue={user.name}
				 ref={input => this.nameRef = input}>
				</input>
				<p style={labelStyle}>Age:</p>
				<input type="number" 
				 min="1" max="100" 
				 style={numberInputStyle}
				 defaultValue={user.age}
				 ref={input => this.ageRef = input}></input>
				<p style={labelStyle}>Role:</p>
				<input type="text"
				 style={textInputStyle}
				 defaultValue={user.role}
				 ref={input => this.roleRef = input}></input>
				<p style={labelStyle}>Image Url:</p>
				<input type="url" 
				 style={textInputStyle}
				 defaultValue={user.img}
				 ref={input => this.imgRef = input}></input>
			</div>
			<div>
			   <button onClick={this.handleSubmit} 
			           style={{textAlign:"center"}}>{buttonTitle}</button>
			</div>
		</div>
		);
	}
}

Create.defaultProps = {
    editMode: false,    // false: Create mode, true: Edit mode
    user: {
        name: "",
		age: 1,
		role: "",
		img:""
    }    
}

const mapStateToProps = (state) => {
	return {
	  users: state.mainReducer.users
	}
}

const mapDispatchToProps = (dispatch) => {
	return {
	  createUser: (user) => {
		  dispatch(createUser(user))  
	  },
	  updateUser: (user) => {
		dispatch(updateUser(user))
	  }
	}
}

export default connect(mapStateToProps, mapDispatchToProps)(Create);
