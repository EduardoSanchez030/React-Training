import actionTypes from "../actions/actionTypes";

const InitialState = {
	users: [],
    loading: true
}

export const mainReducer = (state = InitialState, action) => {
    switch (action.type) {
		case actionTypes.GET_USERS:
            return {
                ...state, users: action.payload.data
			}

		case actionTypes.DELETE_USER:
            return {
                ...state, users: state.users.filter(x => { return x.id !== action.payload })
            }
            
        case actionTypes.UPDATE_USER:
            const newData = state.users.map(obj => {
                if(obj.id === action.payload.id) // check if fieldName equals to cityId
                   return {
                     ...obj,
                     name: action.payload.name,
                     age: action.payload.age,
                     role: action.payload.role,
                     img: action.payload.img
                   }
                return obj
              });
              
            return {...state, users: newData}
            
        case actionTypes.CREATE_USER:
            //to avoid duplicated key, temporary fix
            action.payload.id = Math.floor(Math.random() * 150);
            return {
                ...state, users: state.users.concat(action.payload)
            }
        
        case actionTypes.SHOW_MODAL:
            return {
                ...state, showModal: action.payload
            }

        default:
            break
    }
    return state
}

export default mainReducer;
