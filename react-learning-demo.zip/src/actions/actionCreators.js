import actionTypes from '../actions/actionTypes';
import API from "../middleware/api";

export function getUsers() {
	return dispatch => {
        API.get('/users')
            .then(result => {                
                dispatch({
                    type: actionTypes.GET_USERS,
                    payload: result.data
                })
            })
    }
}

export function deleteUser(id) {
		return dispatch => {
			API.delete('/users').then(
				result => {
					dispatch({
						type: actionTypes.DELETE_USER,
						payload: id
					})
				}
			);
		}
}

export function createUser(user) {
	// I was using this to add the info typed by the user instead of API response
	/* return dispatch => {                
		dispatch({
			type: actionTypes.CREATE_USER,
			payload: user
		})
	} */
	return dispatch => {
		API.post('/users').then(
			result => {
				console.log(result);
				dispatch({
					type: actionTypes.CREATE_USER,
					payload: result.data.data
				})
			}
		);
	}
}

export function updateUser(user) {
	return dispatch => {
		API.put('/users').then(
			result => {
				dispatch({
					type: actionTypes.UPDATE_USER,
					payload: user
				})
			}
		);
    }
}

export function showModal(modal) {
	return  dispatch => {dispatch({type: actionTypes.SHOW_MODAL, payload: modal}); }
}